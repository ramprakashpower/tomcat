# Empty Spring REST example

This is an empty spring boot rest project that uses Tomcat. It was created just to explain a Jenkins deployment. It is not a template project!
 
## Technologies

1. Spring Boot 2.x (spring-boot-starter-web, spring-boot-starter-tomcat)
2. Java 8+
3. Tomcat 8.5.x
4. Maven 3.6.x
 
## Exposed methods

**1. Get user by id. HTTP Method: GET**
```
http://localhost:8080/emptyspringrestexample/users/1
```
